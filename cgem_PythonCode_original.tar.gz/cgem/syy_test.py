import sys
a=sys.argv[1:]
print(len(sys.argv))
